# 1-) Crie uma lista contendo seis frutas de sua escolha.

# 2-) Depois de ter a lista pronta, converta essa lista em uma tupla.

# 3-) Por fim, exiba o conteúdo da tupla resultante para
# verificar as frutas que foram armazenadas.

lista = ['maçã', 'banana', 'uva', 'morango', 'pera', 'melância']

tupla = tuple(lista)

print(type(tupla))
print(tupla)
